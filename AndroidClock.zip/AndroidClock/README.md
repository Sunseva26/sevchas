# AndroidClock

Простое приложение «Часы» для Android (Kotlin): показывает текущее время и дату, обновляется раз в секунду.

## Как получить готовый APK через GitHub Actions

1. Создайте новый репозиторий на GitHub.
2. Загрузите в него все файлы из этого архива (сохранив структуру папок, включая `.github/workflows/build.yml`).
   - Через веб-интерфейс: "Add file" → "Upload files" → перетащите всё содержимое папки.
   - Или через git:
     ```bash
     git init
     git add .
     git commit -m "Initial commit: Android clock app"
     git branch -M main
     git remote add origin https://github.com/ВАШ_ЛОГИН/ВАШ_РЕПОЗИТОРИЙ.git
     git push -u origin main
     ```
3. После пуша откройте вкладку **Actions** в репозитории — запустится workflow **Build APK**.
4. Когда сборка завершится (зелёная галочка), откройте завершённый запуск и внизу, в разделе **Artifacts**, скачайте `app-debug-apk` — это и есть готовый APK, упакованный в zip.
5. Установите APK на Android-устройство (может потребоваться разрешить установку из неизвестных источников).

## Локальная сборка (альтернатива)

Если у вас установлен Android Studio:
1. Откройте папку проекта как существующий проект.
2. Дождитесь синхронизации Gradle.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Готовый файл появится в `app/build/outputs/apk/debug/`.

## Структура проекта

```
app/
  src/main/
    java/com/example/androidclock/MainActivity.kt
    res/layout/activity_main.xml
    res/values/
    AndroidManifest.xml
  build.gradle.kts
.github/workflows/build.yml
build.gradle.kts
settings.gradle.kts
```
